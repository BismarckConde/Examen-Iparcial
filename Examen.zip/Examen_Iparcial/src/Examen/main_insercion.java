package Examen;
import java.util.Arrays;
public class main_insercion {

	public static void main(String[] args) 
	{
		double ac;
		double num[]= {100,-120,300,-0.4,50,170,115};
		
		System.out.println(" ARREGLO ORIGINAL "+Arrays.toString(num));
		insertionSort(num);
		System.out.println(" ARREGLO ORDENADO POR EL METODO DE INSERCION "+Arrays.toString(num));
	}

	public static void insertionSort(double[] num) 
	{
		
		for (int i = 0; i < num.length; i++) 
		{
			double ac = num[i];
			int j = i;
			
			
			while(j>0 && num[j-1]>ac)
			{
				num[j]=num[j-1];
				j--;
			}
			num[j]=ac;
		}
	}
}
