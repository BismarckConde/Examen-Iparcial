package Examen;
import java.util.Scanner;
public class main_loginmenu {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		String us="bismarck",con="conde123",usin,conin;
		int in=0;
		 String productos[] ;
	        Double precios[] ;
	       int cantidades [] ; 
		
		while(in<3)
		{
			System.out.println(" POR FAVOR INTRODUZCA SU USUARIO ");
			usin=tc.nextLine();
			System.out.println(" POR FAVOR INTRODUZACA SU CONTRASEÑA ");
			conin=tc.nextLine();
			
			if (usin.equals(us) && conin.equals(con))
			{
			
				System.out.println(" BIENVENIDO AL PROGRAMA "+us);
				break;
			}
			else 
			{
				System.out.println(" ERROR... EL USUARIO O LA CONTRASEÑA ES INCORRECTOS, INTENLO NUEVAMENTE... ");
				in++;
			}
			
		}
		if (in==3)
		{
			System.out.println(" HA LLEGADO A SU MAXIMO DE INTENTOS ");
		}
		
		 int opcion = 0;
	       
			while (opcion != 4) {
	            System.out.println("\nSeleccione una opción:");
	            System.out.println("1. Registrar productos");
	            System.out.println("2. Realizar trámite");
	            System.out.println("3. Imprimir factura");
	            System.out.println("4. Salir");
	            opcion = tc.nextInt();

	            switch (opcion) {
	                case 1:
	                    System.out.print("Ingresa el nombre del producto: ");
	                    String nombre = tc.next();
	                    System.out.print("Ingresa el precio del producto: ");
	                    double precio = tc.nextDouble();
	                    


	            }
	           
			}
	}
}
	
	

	      
